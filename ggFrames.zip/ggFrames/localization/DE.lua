GGF.locale = {
  ["welcome"] = "Welcome",
}
GGF.localization = {
  ["welcome"] = "Welcome",
}